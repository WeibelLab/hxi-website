---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Artemis: Mixed-reality environment for immersive surgical telementoring'
subtitle: ''
summary: ''
authors:
- Nadir Weibel
- Danilo Gasques
- Janet Johnson
- Thomas Sharkey
- Zhuoqun Robin Xu
- Xinming Zhang
- Enrique Zavala
- Michael Yip
- Konrad Davis
tags: []
categories: []
date: '2020-01-01'
lastmod: 2021-09-23T15:50:57-07:00
featured: false
draft: false
doi: 10.1145/3334480.3383169

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-09-23T22:50:57.002688Z'
publication_types:
- '1'
abstract: ''
publication: '*Extended Abstracts of the 2020 CHI Conference on Human Factors in Computing
  Systems*'
---
