---
# Documentation: https://wowchemy.com/docs/managing-content/

title: Multimodal data analysis and visualization to study the usage of electronic
  health records
subtitle: ''
summary: ''
authors:
- Nadir Weibel
- Shazia Ashfaq
- Alan Calvitti
- James D Hollan
- Zia Agha
tags: []
categories: []
date: '2013-01-01'
lastmod: 2021-09-23T15:50:38-07:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-09-23T22:50:38.344189Z'
publication_types:
- '1'
abstract: ''
publication: '*2013 7th International Conference on Pervasive Computing Technologies
  for Healthcare and Workshops*'
---
