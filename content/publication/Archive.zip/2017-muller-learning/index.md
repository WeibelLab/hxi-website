---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Learning from failure: designing for complex sociotechnical systems'
subtitle: ''
summary: ''
authors:
- Lars Müller
- Matthias Budde
- Nadir Weibel
- Eliah Aronoff Spencer
- Michael Beigl
- Don Norman
tags: []
categories: []
date: '2017-01-01'
lastmod: 2021-09-23T15:50:48-07:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-09-23T22:50:48.474812Z'
publication_types:
- '1'
abstract: ''
publication: '*Proceedings of the 2017 ACM International Joint Conference on Pervasive
  and Ubiquitous Computing and Proceedings of the 2017 ACM International Symposium
  on Wearable Computers*'
---
