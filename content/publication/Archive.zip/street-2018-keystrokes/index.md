---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'Keystrokes, mouse clicks, and gazing at the computer: how physician interaction
  with the EHR affects patient participation'
subtitle: ''
summary: ''
authors:
- Richard L Street
- Lin Liu
- Neil J Farber
- Yunan Chen
- Alan Calvitti
- Nadir Weibel
- Mark T Gabuzda
- Kristin Bell
- Barbara Gray
- Steven Rick
- ' others'
doi: 10.1007/s11606-017-4228-2doi
tags: []
categories: []
date: '2018-01-01'
lastmod: 2021-09-23T15:50:49-07:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-09-23T22:50:49.322464Z'
publication_types:
- '2'
abstract: ''
publication: '*Journal of general internal medicine*'
---
