---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'NeuroPose: geriatric rehabilitation in the home using a webcam and pose estimation'
subtitle: ''
summary: ''
authors:
- Steven R Rick
- Shubha Bhaskaran
- Yajie Sun
- Sarah McEwen
- Nadir Weibel
doi: 10.1145/3308557.3308682
tags: []
categories: []
date: '2019-01-01'
lastmod: 2021-09-23T15:50:53-07:00
featured: false
draft: false

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-09-23T22:50:53.007981Z'
publication_types:
- '1'
abstract: Many chronic diseases and common risks to elderly patients can be assessed and treated through standardized training and rehabilitation programs. Unfortunately, there is a need to make risk assessment and preventative care for the elderly more easily accessible as many programs either use specialized hardware or require human supervision. We seek to reduce the barrier to entry for patients through a portable application which enables fall risk prevention assessment and rehabilitation anywhere. Our work leverages the latest in machine learning and computer vision, accomplishing pose estimation and body tracking with a simple and ubiquitous web cam. Thus patients can be screened anywhere with the ability to get feedback in near-real time.
publication: '*Proceedings of the 24th International Conference on Intelligent User
  Interfaces: Companion*'
---
