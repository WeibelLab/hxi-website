---
# Documentation: https://wowchemy.com/docs/managing-content/

title: 'HIV risk on twitter: The ethical dimension of social media evidence-based
  prevention for vulnerable populations'
subtitle: ''
summary: ''
authors:
- Nadir Weibel
- Purvi Desai
- Lawrence Saul
- Amarnath Gupta
- Susan Little
tags: []
categories: []
date: '2017-01-01'
lastmod: 2021-09-23T15:50:45-07:00
featured: false
draft: false
doi:  10.24251/HICSS.2017.216

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.
# Focal points: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight.
image:
  caption: ''
  focal_point: ''
  preview_only: false

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
projects: []
publishDate: '2021-09-23T22:50:45.644700Z'
publication_types:
- '1'
abstract: ''
publication: '*Proceedings of the 50th Hawaii International Conference on System Sciences*'
---
